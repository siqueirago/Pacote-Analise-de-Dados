# My Data Analysis Package

Este é um pacote Python simples para análise de dados utilizando Pandas.

## Instalação

Você pode instalar o pacote usando usando o gerenciador de pacotes p [pip](https://pip.pypa.io/en/stable/) para o pacote_analise_dados.

``` basch
pip install pacote_analysis_dados
```


## Uso

``` python
from  my_data_analysis_package impory analize_data
```

## Autor

Julio Siqueira

## Licença

[MIT](https://choosealicense.com/licenses/mit/)
