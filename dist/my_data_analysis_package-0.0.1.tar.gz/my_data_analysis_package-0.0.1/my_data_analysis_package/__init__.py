# my_data_analysis_package/__init__.py

from .analysis import analyze_data
