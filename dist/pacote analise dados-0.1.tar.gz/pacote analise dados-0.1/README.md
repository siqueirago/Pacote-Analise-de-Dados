# Meu Pacote Análise de dados

Este é um pacote de exemplo para fins educativos, criado para demonstrar como enviar um pacote Python para o PyPI.

## Instalação

Você pode instalar o pacote usando usando o gerenciador de pacotes p [pip](https://pip.pypa.io/en/stable/) para o pacote_analise_dados.

## Autor

Julio Siqueira

## Licença

[MIT](https://choosealicense.com/licenses/mit/)
